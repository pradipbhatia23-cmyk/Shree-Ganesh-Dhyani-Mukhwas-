SHREE GANESH MUKHWAS WEBSITE

Preview: Open index.html in a modern browser.

Files:
- index.html: responsive landing page with styling and interactions
- assets/: product images supplied by you

Before publishing:
1. Confirm the WhatsApp number in the enquiry link in index.html.
2. Add verified ingredients, pack size, price, business address, and delivery information if desired.
3. For online payments/cart functionality, connect a trusted commerce/payment provider.

The website uses Google Fonts when internet access is available; system fallbacks are included.
